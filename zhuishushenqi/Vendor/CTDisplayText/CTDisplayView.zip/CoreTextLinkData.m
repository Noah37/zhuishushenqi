//
//  CoreTextLinkData.m
//  CoreTextDemo
//
//  Created by caonongyun on 2017/7/25.
//  Copyright © 2017年 QS. All rights reserved.
//

#import "CoreTextLinkData.h"

@implementation CoreTextLinkData

@end
